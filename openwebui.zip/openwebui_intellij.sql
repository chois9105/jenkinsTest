create table public.migratehistory
(
    id          serial
        primary key,
    name        varchar(255) not null,
    migrated_at timestamp    not null
);

alter table public.migratehistory
    owner to openwebui;

create table public.auth
(
    id       varchar(255) not null,
    email    varchar(255) not null,
    password text         not null,
    active   boolean      not null
);

alter table public.auth
    owner to openwebui;

create unique index auth_id
    on public.auth (id);

create table public.chat
(
    id         varchar(255)            not null,
    user_id    varchar(255)            not null,
    title      text                    not null,
    share_id   varchar(255),
    archived   boolean                 not null,
    created_at bigint                  not null,
    updated_at bigint                  not null,
    chat       json,
    pinned     boolean,
    meta       json default '{}'::json not null,
    folder_id  text
);

alter table public.chat
    owner to openwebui;

create unique index chat_id
    on public.chat (id);

create unique index chat_share_id
    on public.chat (share_id);

create table public.chatidtag
(
    id        varchar(255) not null,
    tag_name  varchar(255) not null,
    chat_id   varchar(255) not null,
    user_id   varchar(255) not null,
    timestamp bigint       not null
);

alter table public.chatidtag
    owner to openwebui;

create unique index chatidtag_id
    on public.chatidtag (id);

create table public.document
(
    id              serial
        primary key,
    collection_name varchar(255) not null,
    name            varchar(255) not null,
    title           text         not null,
    filename        text         not null,
    content         text,
    user_id         varchar(255) not null,
    timestamp       bigint       not null
);

alter table public.document
    owner to openwebui;

create unique index document_collection_name
    on public.document (collection_name);

create unique index document_name
    on public.document (name);

create table public.prompt
(
    id             serial
        primary key,
    command        varchar(255) not null,
    user_id        varchar(255) not null,
    title          text         not null,
    content        text         not null,
    timestamp      bigint       not null,
    access_control json
);

alter table public.prompt
    owner to openwebui;

create unique index prompt_command
    on public.prompt (command);

create table public.tag
(
    id      varchar(255) not null,
    name    varchar(255) not null,
    user_id varchar(255) not null,
    meta    json,
    constraint pk_id_user_id
        primary key (id, user_id)
);

alter table public.tag
    owner to openwebui;

create table public."user"
(
    id                varchar(255) not null,
    name              varchar(255) not null,
    email             varchar(255) not null,
    role              varchar(255) not null,
    profile_image_url text         not null,
    api_key           varchar(255),
    created_at        bigint       not null,
    updated_at        bigint       not null,
    last_active_at    bigint       not null,
    settings          text,
    info              text,
    oauth_sub         text,
    employment_no     varchar(255)
);

alter table public."user"
    owner to openwebui;

create unique index user_id
    on public."user" (id);

create unique index user_api_key
    on public."user" (api_key);

create unique index user_oauth_sub
    on public."user" (oauth_sub);

create table public.memory
(
    id         varchar(255) not null,
    user_id    varchar(255) not null,
    content    text         not null,
    updated_at bigint       not null,
    created_at bigint       not null
);

alter table public.memory
    owner to openwebui;

create unique index memory_id
    on public.memory (id);

create table public.model
(
    id             text                 not null,
    user_id        text                 not null,
    base_model_id  text,
    name           text                 not null,
    meta           text                 not null,
    params         text                 not null,
    created_at     bigint               not null,
    updated_at     bigint               not null,
    access_control json,
    is_active      boolean default true not null
);

alter table public.model
    owner to openwebui;

create unique index model_id
    on public.model (id);

create table public.tool
(
    id             text   not null,
    user_id        text   not null,
    name           text   not null,
    content        text   not null,
    specs          text   not null,
    meta           text   not null,
    created_at     bigint not null,
    updated_at     bigint not null,
    valves         text,
    access_control json
);

alter table public.tool
    owner to openwebui;

create unique index tool_id
    on public.tool (id);

create table public.file
(
    id             text   not null,
    user_id        text   not null,
    filename       text   not null,
    meta           json,
    created_at     bigint not null,
    hash           text,
    data           json,
    updated_at     bigint,
    path           text,
    access_control json
);

alter table public.file
    owner to openwebui;

create unique index file_id
    on public.file (id);

create table public.function
(
    id         text    not null,
    user_id    text    not null,
    name       text    not null,
    type       text    not null,
    content    text    not null,
    meta       text    not null,
    created_at bigint  not null,
    updated_at bigint  not null,
    valves     text,
    is_active  boolean not null,
    is_global  boolean not null
);

alter table public.function
    owner to openwebui;

create unique index function_id
    on public.function (id);

create table public.alembic_version
(
    version_num varchar(32) not null
        constraint alembic_version_pkc
            primary key
);

alter table public.alembic_version
    owner to openwebui;

create table public.config
(
    id         serial
        primary key,
    data       json                    not null,
    version    integer                 not null,
    created_at timestamp default now() not null,
    updated_at timestamp default now()
);

alter table public.config
    owner to openwebui;

create table public.knowledge
(
    id             text   not null
        primary key,
    user_id        text   not null,
    name           text   not null,
    description    text,
    data           json,
    meta           json,
    created_at     bigint not null,
    updated_at     bigint,
    access_control json
);

alter table public.knowledge
    owner to openwebui;

create table public.folder
(
    id          text    not null,
    parent_id   text,
    user_id     text    not null,
    name        text    not null,
    items       json,
    meta        json,
    is_expanded boolean not null,
    created_at  bigint  not null,
    updated_at  bigint  not null,
    primary key (id, user_id)
);

alter table public.folder
    owner to openwebui;

create table public.feedback
(
    id         text   not null
        primary key,
    user_id    text,
    version    bigint,
    type       text,
    data       json,
    meta       json,
    snapshot   json,
    created_at bigint not null,
    updated_at bigint not null
);

alter table public.feedback
    owner to openwebui;

create table public."group"
(
    id          text not null
        primary key,
    user_id     text,
    name        text,
    description text,
    data        json,
    meta        json,
    permissions json,
    user_ids    json,
    created_at  bigint,
    updated_at  bigint
);

alter table public."group"
    owner to openwebui;

create table public.channel
(
    id             text not null
        primary key,
    user_id        text,
    name           text,
    description    text,
    data           json,
    meta           json,
    access_control json,
    created_at     bigint,
    updated_at     bigint,
    type           text
);

alter table public.channel
    owner to openwebui;

create table public.message
(
    id         text not null
        primary key,
    user_id    text,
    channel_id text,
    content    text,
    data       json,
    meta       json,
    created_at bigint,
    updated_at bigint,
    parent_id  text
);

alter table public.message
    owner to openwebui;

create table public.message_reaction
(
    id         text not null
        primary key,
    user_id    text not null,
    message_id text not null,
    name       text not null,
    created_at bigint
);

alter table public.message_reaction
    owner to openwebui;

create table public.channel_member
(
    id         text not null
        primary key,
    channel_id text not null,
    user_id    text not null,
    created_at bigint
);

alter table public.channel_member
    owner to openwebui;

